import React, { useState, useRef } from "react";
import io from "socket.io-client";

const socket = io("http://localhost:3000");

function App() {
  const localVideo = useRef();
  const remoteVideo = useRef();
  const [pc, setPc] = useState(null);

  const startCall = async () => {
    const peerConnection = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
    });

    setPc(peerConnection);

    peerConnection.ontrack = (event) => {
      remoteVideo.current.srcObject = event.streams[0];
    };

    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });

    stream.getTracks().forEach(track =>
      peerConnection.addTrack(track, stream)
    );

    localVideo.current.srcObject = stream;

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit("offer", offer);

    socket.on("answer", async (answer) => {
      await peerConnection.setRemoteDescription(answer);
    });

    socket.on("candidate", async (candidate) => {
      await peerConnection.addIceCandidate(candidate);
    });

    peerConnection.onicecandidate = (event) => {
      if (event.candidate) socket.emit("candidate", event.candidate);
    };
  };

  return (
    <div>
      <h2>ফ্রি ভিডিও কল ডেটিং</h2>
      <video ref={localVideo} autoPlay playsInline />
      <video ref={remoteVideo} autoPlay playsInline />
      <button onClick={startCall}>Start Call</button>
    </div>
  );
}

export default App;
